//
//  TestLib.h
//  TestLib
//
//  Created by 王亮 on 2024/5/6.
//

#import <Foundation/Foundation.h>

//! Project version number for TestLib.
FOUNDATION_EXPORT double TestLibVersionNumber;

//! Project version string for TestLib.
FOUNDATION_EXPORT const unsigned char TestLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestLib/PublicHeader.h>


#import <TestLib/TestLog.h>
