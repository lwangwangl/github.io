//
//  TestLog.h
//  TestLib
//
//  Created by 王亮 on 2024/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestLog : NSObject

+ (void)log:(NSString *)msg;

@end

NS_ASSUME_NONNULL_END
